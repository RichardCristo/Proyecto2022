var n1 = 0;
function sumarAlCarrito(){
    n1 ++;
    document.getElementById("contadorCarrito").innerHTML = n1;
}

function agregarAlCarritoClasica(){
    sumarAlCarrito();
    document.getElementById("datosClasica").innerHTML = "clasica";
}

function agregarAlCarritoNoble(){
    sumarAlCarrito();
    document.getElementById("datosNoble").innerHTML = "noble";
}

function agregarAlCarritoMonarca(){
    sumarAlCarrito();
    document.getElementById("datosMonarca").innerHTML = "monarca";
}

function agregarAlCarritoPollo(){
    sumarAlCarrito();
    document.getElementById("datosPollo").innerHTML = "chicken special";
}

function agregarAlCarritoQueso(){
    sumarAlCarrito();
    document.getElementById("datosQueso").innerHTML = "cheeseburguer";
}

function agregarAlCarritoVegana(){
    sumarAlCarrito();
    document.getElementById("datosVegana").innerHTML = "vegana";
}


function prueba(){
    nombre="a";
    fetch('http://localhost:8080/menu',{method:'GET'})
    .then(response => {
        response.json().then(data => {
            nombre=JSON.stringify(data[1].nombre);
            console.log(nombre);
            document.getElementById("nombre1").innerHTML = nombre;
        })
    });
}

function prueba2(){
    aux = " ";
    fetch('http://localhost:8080/menu',{method:'GET'})
    .then(response=>{
        response.json().then(data =>{
        for(i = 1; Object.keys(data).length >= i; i++ ){
            aux = JSON.stringify(data[i].nombre);
            document.getElementById("col1").innerHTML  = 
            "<div class='col' id='col1'><div class='card' style='width: 18rem;'><img src='burga clasica.jpg' class='card-img-top' alt='...'><div class='card-body'><h5 class='card-title' id='nombreHamburguesa'> "+aux+" </h5> <p class='card-text'>Hamburguesa de carne 120g, con cheddar, lechuga, tomate y salsa de la casa </p><p class='card-text'>Precio: $1000</p> <a href='#' class='btn btn-primary colorBoton' onclick= 'agregarAlCarritoClasica()'>Añadir al carrito</a> </div></div> </div>"
        }
        })
    });
}